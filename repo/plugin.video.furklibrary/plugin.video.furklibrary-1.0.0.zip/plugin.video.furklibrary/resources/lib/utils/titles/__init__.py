# make importing these a bit less hassle
from series import SeriesParser
from movie import MovieParser
from parser import TitleParser, ParseWarning
