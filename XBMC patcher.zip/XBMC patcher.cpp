#include <fstream>
#include <iostream>
#include <string> 
using namespace std;

bool compare(char* ptr, char* comp, int length){
	if(length == 1)
		return true;
	if(ptr[0] == comp[0])
		return compare(ptr+1, comp+1, length-1);
	else
		return false;
}

int main(int argc, char* argv[])
{
	int index;
	long length;
	char* buffer;

	//Data sequence to search for:
	int s_length = 20;
	char* sequence = new char[s_length];
	sequence[0] = (char)0x2E;
	sequence[1] = (char)0x70;
	sequence[2] = (char)0x6C;
	sequence[3] = (char)0x73;
	sequence[4] = (char)0x00;
	sequence[5] = (char)0x00;
	sequence[6] = (char)0x00;
	sequence[7] = (char)0x00;
	sequence[8] = (char)0x2E;
	sequence[9] = (char)0x73;
	sequence[10] = (char)0x74;
	sequence[11] = (char)0x72;
	sequence[12] = (char)0x6D;
	sequence[13] = (char)0x00;
	sequence[14] = (char)0x00;
	sequence[15] = (char)0x00;
	sequence[16] = (char)0x2E;
	sequence[17] = (char)0x77;
	sequence[18] = (char)0x70;
	sequence[19] = (char)0x6C;

	cout << "[XBMC strm patcher]" << endl;
	cout << "-------------------" << endl;
	
	cout << "Reading binary data from XBMC.exe...";
	ifstream in_file("XBMC.exe", ifstream::in | ifstream::binary);
	in_file.seekg (0, ios::end);
	length = in_file.tellg();
	in_file.seekg (0, ios::beg);
	buffer = new char [length];
	in_file.read(buffer,length);
	in_file.close();
	cout << "done" << endl;

	cout << "Trying to find place to modify...";
	index = -1;
	for(int i = 0; i < length-s_length; i++){
		if(compare(buffer+i, sequence, s_length)){
			index = i;
			break;
		}
	}
	if(index < 0){
		cout << "failed" << endl;
		return 0;
	}
	else
		cout << "done" << endl;

	cout << "Creating a backup copy named XBMC.bak...";
	ofstream bak_file("XBMC.bak", ostream::out | fstream::binary);
	bak_file.write (buffer,length);
	bak_file.close();
	cout << "done" << endl;

	cout << "Modifying bytes...";
	buffer[index+9] = 'x';
	buffer[index+10] = 'x';
	buffer[index+11] = 'x';
	buffer[index+12] = 'x';
	cout << "done" << endl;

	cout << "Saving modified XBMC.exe...";
	ofstream out_file("XBMC.exe", ostream::out | fstream::binary);
	out_file.write(buffer,length);
	out_file.close();
	cout << "done" << endl;

	return 0;
}

